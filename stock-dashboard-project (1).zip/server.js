
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const users = {};

const stocks = ['GOOG','TSLA','AMZN','META','NVDA'];
let prices = {
  GOOG: 1000, TSLA: 800, AMZN: 1200, META: 900, NVDA: 1500
};

io.on('connection', (socket) => {
  socket.on('login', (email) => {
    users[socket.id] = { email, subscriptions: [] };
  });

  socket.on('subscribe', (ticker) => {
    if (users[socket.id] && stocks.includes(ticker)) {
      users[socket.id].subscriptions.push(ticker);
    }
  });

  socket.on('disconnect', () => delete users[socket.id]);
});

setInterval(() => {
  stocks.forEach(stock => {
    prices[stock] = +(prices[stock] + (Math.random() * 20 - 10)).toFixed(2);
  });

  Object.keys(users).forEach(id => {
    const user = users[id];
    const data = {};
    user.subscriptions.forEach(t => data[t] = prices[t]);
    io.to(id).emit('priceUpdate', data);
  });
}, 1000);

server.listen(3000, () => console.log('Server running on port 3000'));
